/*
 * Author: Sundar Krishnakumar
 * Brief: Raw image capture and storage in .ppm / .pgm format
 *        
 *       
          Real time image capture using SCHED_FIFO pthreads 1Hz
 * Code reference : http://jwhsmith.net/2014/12/capturing-a-webcam-stream-using-v4l2/
                    
                    
 */

#define _GNU_SOURCE  
#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <linux/videodev2.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <sched.h>
#include <semaphore.h>
#include <mqueue.h>         
#include <stdlib.h>  
#include <sys/utsname.h>   
#include <signal.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/socket.h>

#define HRES 640
#define VRES 480
#define PIXELS ((HRES) * (VRES))
#define HRES_STR  "640"
#define VRES_STR  "480"


// #define LOG // Define to log metrics.Define before NUM_THREADS macro.
// #define GRAY // Output files are .pgm graymap
#define RGB // Output files are .ppm colour rgb
// #define DTI // Difference threashold image output
#define SOC // Enables socket send feature

#define CAMERA "/dev/video0"

#define FRAME_COUNT 1801

#define MSG_PRI (30) // constant priority for all messages.So FIFO order followed at reception
#define BUFF_CNT 4

#define NR_THREADS 2

#ifdef LOG
#define NUM_THREADS 4
#endif

#ifndef LOG
#define NUM_THREADS 3
#endif

#define _GNU_SOURCE

#define NSEC_PER_MSEC (1000000)
#define SEC_TO_MSEC (1000)
#define SEQ_FREQ 100
#define CAP_FREQ_MOD 4 // 10 for 10Hz
#define FPS 1
#define CALIB 0
#define MAX_SLEEP_CALL 3
#define MAXVAL (255)
#define BIN_THRESH (0.06)

// #define DIFF_THRESH (0.002) // In percentage
#define DIFF_THRESH (0.01) // In percentage for 1Hz


#define MESSAGE_Q "/my_queue"
#define MESSAGE_Q1 "/my_queue1"
#define MQ_LENGTH 50

// all struct forward declarations here
typedef struct
{
	int threadIdx;

} typedef_threadParams;

#ifdef GRAY

typedef struct
{
	char g_buffer[PIXELS]; // Takes this space after YUV to gray conversion
	char im_header[200];
	int set_no;

} typedef_payload;

#endif


#ifdef RGB

typedef struct
{
	char c_buffer[((PIXELS)*3)]; // Takes this space after YUV to RGB conversion
	char g_buffer[PIXELS]; // Takes this space after YUV to gray conversion
	char im_header[200];
	int set_no;

} typedef_payload;

#endif



// all global variables here

int frm_no; // incremented inside sequencer.Used in all service threads
int stop_bit; // toggled inside sequencer
long int seq_cnt = 0; // must start at 0
int first = 1;

sem_t semC;
sem_t semS;
sem_t sem; //  for nesting service thread's C.S because DQ_BUF ioctl call is blocking call.
// sem_t semG;
// sem_t semB;
sem_t semL;


// Used inside yuv2rgb and sharpen_image
// cannot be local 
// char convR[PIXELS];
// char convG[PIXELS];
// char convB[PIXELS];

// char R[PIXELS];
// char G[PIXELS];
// char B[PIXELS];

// char gray[PIXELS]; // buffer for grayscale image
typedef_payload payload[MQ_LENGTH];
struct timespec mq_timeout = {0};


// message queue related
mqd_t mqd; // message queue descriptor mq1 in diagram
mqd_t mqd1; // message queue descriptor mq2 in diagram

// struct mq_attr {
//     long mq_flags;       /* Flags: 0 or O_NONBLOCK */
//     long mq_maxmsg;      /* Max. # of messages on queue */
//     long mq_msgsize;     /* Max. message size (bytes) */
//     long mq_curmsgs;     /* # of messages currently in queue */
// };
struct mq_attr attr = {0}; // message queue attribute data-structure.
struct mq_attr attr1 = {0}; // message queue attribute data-structure.

// Metrics variables

double et_capture;
double et_send;
double et_sequencer;

double et_process;


double wcet_capture = 0; // max et
double wcet_send = 0 ; // max et
double wcet_sequencer = 0; //  max et

double wcet_process = 0; // max et
double deadline = (1.0 / (SEQ_FREQ / CAP_FREQ_MOD)); // total execution > deadline => deadline_miss = YES 
double s_deadline = (1.0 / SEQ_FREQ);



struct timespec begin; // for services
struct timespec end; // for services
struct timespec s_begin; // for services
struct timespec s_end; // for services

struct timespec process_begin;
struct timespec process_end;

// Sequencer specific.Do not use anywhere else.Configured inside main and sequencer.
static timer_t timer_1;
static struct itimerspec itime;
static struct itimerspec last_itime;
struct sigevent sev = {0};

// Sequencer specific.Do not use anywhere else
struct timespec runtime; 
struct timespec start; 
double time_elapsed; 



// socket related
int socket_desc;
struct sockaddr_in server_addr;
char frm_buffer[((PIXELS) * 3) + 200]; // 550 is for ppm/pgm header info.


// Source: https://devarea.com/linux-handling-signals-in-a-multithreaded-application/#.XyT0bBmYWbk
void mask_sig()
{
	sigset_t mask;
	sigemptyset(&mask); 
   sigaddset(&mask, SIGRTMIN); 
                
   pthread_sigmask(SIG_BLOCK, &mask, NULL);
        
}


// Code reference: http://ecee.colorado.edu/~ecen5623/ecen/ex/Linux/RT-Clock/posix_clock.c
// Convert to double precision seconds
double d_ftime(struct timespec *fstart, struct timespec *fstop)
{
  double dfstart = ((double)(fstart->tv_sec) + ((double)(fstart->tv_nsec) / 1000000000.0));
  double dfstop = ((double)(fstop->tv_sec) + ((double)(fstop->tv_nsec) / 1000000000.0)); 

  return (double)(dfstop - dfstart); 
}

// Conversion of yuvu to rgb
// Code source : http://ecee.colorado.edu/~ecen5623/ecen/ex/Linux/computer-vision/simple-capture/capture.c
void yuv2rgb(int y, int u, int v, unsigned char *r, unsigned char *g, unsigned char *b)
{  
	int r1, g1, b1;

	// replaces floating point coefficients
	int c = y-16, d = u - 128, e = v - 128;       

	// Conversion that avoids floating point
	r1 = (298 * c           + 409 * e + 128) >> 8;
	g1 = (298 * c - 100 * d - 208 * e + 128) >> 8;
	b1 = (298 * c + 516 * d           + 128) >> 8;

	// Computed values may need clipping.
	if (r1 > 255) r1 = 255;
	if (g1 > 255) g1 = 255;
	if (b1 > 255) b1 = 255;

	if (r1 < 0) r1 = 0;
	if (g1 < 0) g1 = 0;
	if (b1 < 0) b1 = 0;

	*r = r1 ;
	*g = g1 ;
	*b = b1 ;
}

// ppm header and ppm file name string should be terminated by null.
// strlen used to calc ppm header size
void save_image(char *PPM_fname, char *PPM_header, char *buffer, int buff_size)
{

	int fd1;	

	// Saving the PPM file
	if ((fd1 = open(PPM_fname, O_WRONLY | O_CREAT, 0777)) < 0)
	{

		perror("While creating PPM image file");
		exit(1);

	}


	// syslog(LOG_INFO,"%s\n", PPM_header);
	// Write the PPM header
	// IMPORTANT: Never use sizeof.It will print remaining garbage after 255\n in the pixel area.
	// This causes purple tint as pixel is corrupted by ppm header
	write(fd1, PPM_header, strlen(PPM_header)); 
	// syslog(LOG_INFO,"header size: %d\n", (int)strlen(PPM_header));
	// Write the colour space : YUYV format
	// char header[] = "P6 640 480 255\n";
	// write(fd1, header, sizeof(header));

	// Write the colour space : RGB format
	write(fd1, buffer, buff_size);
	close(fd1);

}

void process_image(char *buffptr, char *gbuffer, char *cbuffer, int size)
{



	if (buffptr == NULL)
	{
		fprintf(stderr, "Buffptr is NULL\n");
		exit(1);
	}

	// k follows the index of separate rgb channels
	int y1_temp, y2_temp, u_temp, v_temp, i, j, k;


// #ifdef LOG
// 	clock_gettime(CLOCK_REALTIME, &process_begin);
// #endif

	for(i = 0, k = 0, j = 0; i < size; i = i + 4, j = j + 6, k = k + 2)
	{

		gbuffer[k] = y1_temp = (int)buffptr[i];  // luminance component		
		gbuffer[k+1] = y2_temp = (int)buffptr[i+2]; // luminance component 	

#ifdef RGB
		u_temp = (int)buffptr[i+1]; 	
		v_temp = (int)buffptr[i+3];

		yuv2rgb(y1_temp, u_temp, v_temp, &cbuffer[j], &cbuffer[j+1], &cbuffer[j+2]);
		yuv2rgb(y2_temp, u_temp, v_temp, &cbuffer[j+3], &cbuffer[j+4], &cbuffer[j+5]);
#endif
		// Split pixel space to RGB channels.
		// For use in sharpen_image service
		// R[k] = cbuffer[j];
		// R[k+1] = cbuffer[j+3];

		// G[k] = cbuffer[j+1];
		// G[k+1] = cbuffer[j+4];

		// B[k] = cbuffer[j+2];
		// B[k+1] = cbuffer[j+5];
	}

// #ifdef LOG
// 	clock_gettime(CLOCK_REALTIME, &process_end);
// 	et_process = d_ftime(&process_begin, &process_end);
// 	if (et_process > wcet_process) wcet_process = et_process;
// #endif

	
}

int fd, i, j, k, buff_index, set_cnt = 0, new_set_cnt = 0;
struct v4l2_format format;
struct v4l2_requestbuffers buff_rq;
struct v4l2_buffer buff_info;
void *buffer[BUFF_CNT]; // holds the pointers to mmap.They point to raw image location
int type; // holds value of buff_info.type  Here: V4L2_BUF_TYPE_VIDEO_CAPTURE
unsigned long int capture_cnt;
char mq_buffer[sizeof(void *)];
typedef_payload * mq_payload = NULL;

char timestamp[25];
struct timespec timestamp_struct;

char str_uname[400];
struct utsname unamedata;

// image capture happens here
void *capture_image(void *threadp)
{

	typedef_threadParams *thread_param = (typedef_threadParams *)threadp;

	if (thread_param->threadIdx == 1)
	{
		mask_sig();
		for (j = 0; j < BUFF_CNT; j++)
		{

			buffer[j] = NULL;
		}

		if ((fd = open(CAMERA, O_RDWR)) < 0)
		{
			perror("Opening camera file");
			exit(1);

		}

		// Set image format here
		format.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		// Support available.Checked with v4l2-ctl -d /dev/video0 --list-formats-ext
		format.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV; 
		// format.fmt.pix.pixelformat = V4L2_PIX_FMT_MJPEG; 
		format.fmt.pix.width = HRES;
		format.fmt.pix.height = VRES;

		if (ioctl(fd, VIDIOC_S_FMT, &format) < 0)
		{
			perror("VIDIOC_S_FMT");
			exit(1);
		}

		// Request buffers here
		buff_rq.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		buff_rq.memory = V4L2_MEMORY_MMAP;
		buff_rq.count = BUFF_CNT;

		if (ioctl(fd, VIDIOC_REQBUFS, &buff_rq) < 0)
		{
			perror("VIDIOC_REQBUFS");
			exit(1);
		}

		syslog(LOG_INFO,"Number of buffers allocated: %d\n", buff_rq.count);
		for (j = 0; j < BUFF_CNT; j++)
		{
			// To get length and offset for doing mmap and retreiving pointer
			memset(&buff_info, 0, sizeof(buff_info)); // Protection against garbage values

			buff_info.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
			buff_info.memory = V4L2_MEMORY_MMAP;
			buff_info.index = j;

			if (ioctl(fd, VIDIOC_QUERYBUF, &buff_info) < 0)
			{
				perror("VIDIOC_QUERYBUF");
				exit(1);
			}

			buffer[j] = mmap(NULL, buff_info.length, PROT_READ | PROT_WRITE, MAP_SHARED, fd, buff_info.m.offset);
			if ((buffer == NULL) || (buffer == MAP_FAILED))
			{
				perror("While doing mmap");
				exit(1);

			}

			// Put the  buffer to incoming queue 
			if (ioctl(fd, VIDIOC_QBUF, &buff_info) < 0)
			{
					perror("VIDIOC_QBUF");
					exit(1);
			}

		}
		
		type = buff_info.type;

		// Start streaming
		if (ioctl(fd, VIDIOC_STREAMON, &type) < 0)
		{
			perror("VIDIOC_STREAMON");
			exit(1);
		
		}



		// Start continuous capture
		// frm_no = 0;
		capture_cnt = 0;
		set_cnt = 0;
		while (1)
		{		

			sem_wait(&semC);
			if (stop_bit == 1) break;
			//sem_wait(&sem);
			syslog(LOG_INFO,"capturing: %ld\n", capture_cnt);
#ifdef LOG
			clock_gettime(CLOCK_REALTIME, &begin);
#endif

			if (seq_cnt < SEQ_FREQ)		
			{


				memset(&buff_info, 0, sizeof(buff_info));
				buff_info.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
				buff_info.memory = V4L2_MEMORY_MMAP;


				// Release the buffer from the outgoing queue of the driver.
				// IMPORTANT: Blocking call.Will block the calling thread.
				if (ioctl(fd, VIDIOC_DQBUF, &buff_info) < 0)
				{
					perror("VIDIOC_DQBUF");
					exit(1);
				}
				// Got the image


				if (!((buff_info.index >= 0) && (buff_info.index < BUFF_CNT)))
				{
					syslog(LOG_INFO,"Incorrect buffer index\n");
					exit(1);
				}

				syslog(LOG_INFO,"Buffer index: %d\n", buff_info.index);

				// Put the  buffer to incoming queue 
				if (ioctl(fd, VIDIOC_QBUF, &buff_info) < 0)
				{
						perror("VIDIOC_QBUF");
						exit(1);
				}

				syslog(LOG_INFO,"Capture discarded %ld\n", capture_cnt);
				//sem_post(&sem);
				continue;
				
			}

			// index changes here
			i = (capture_cnt % MQ_LENGTH);

			memset(&buff_info, 0, sizeof(buff_info));
			buff_info.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
			buff_info.memory = V4L2_MEMORY_MMAP;


			// IMPORTANT: Take timestamp here
			clock_gettime(CLOCK_REALTIME, &timestamp_struct);

			// Release the buffer from the outgoing queue of the driver.
			// IMPORTANT: Blocking call.Will block the calling thread.
			sem_wait(&sem);
			if (ioctl(fd, VIDIOC_DQBUF, &buff_info) < 0)
			{
				perror("VIDIOC_DQBUF");
				exit(1);
			}
			// Got the image
			sem_post(&sem);

			if (!((buff_info.index >= 0) && (buff_info.index < BUFF_CNT)))
			{
				syslog(LOG_INFO,"Incorrect buffer index\n");
				exit(1);
			}

			buff_index = buff_info.index;
			syslog(LOG_INFO,"Buffer index: %d\n", buff_index);
			
#ifdef GRAY
			// CONVERT TO GRAY		
			process_image(buffer[buff_index], payload[i].g_buffer, NULL, buff_info.length);

#endif

#ifdef RGB
			// CONVERT TO GRAY		
			process_image(buffer[buff_index], payload[i].g_buffer, payload[i].c_buffer, buff_info.length);

#endif

			// Put the  buffer to incoming queue 
			if (ioctl(fd, VIDIOC_QBUF, &buff_info) < 0)
			{
					perror("VIDIOC_QBUF");
					exit(1);
			}


#ifdef LOG
			clock_gettime(CLOCK_REALTIME, &end);
			et_capture = d_ftime(&begin, &end);
			if (et_capture > wcet_capture) wcet_capture = et_capture;
#endif

			syslog(LOG_INFO,"capture  complete : %ld\n", capture_cnt);
			// sem_post(&sem);

		}


		// Stop streaming
		if (ioctl(fd, VIDIOC_STREAMOFF, &type) < 0)
		{
			perror("VIDIOC_STREAMOFF");
			exit(1);
		}
		
		// syslog(LOG_INFO,"%d\n", buff_info.length);
		// syslog(LOG_INFO,"%d\n", buff_info.bytesused);

		close(fd);
		syslog(LOG_INFO,"Exiting capture service\n");
		pthread_exit(NULL);

		

	} // end of capture service

	// Start of send image service
	if (thread_param->threadIdx == 2)
	{
		mask_sig();
		while(1)
		{

			sem_wait(&semS);
			if (stop_bit == 1) break;
			sem_wait(&sem);
			syslog(LOG_INFO,"send  start : %ld\n", capture_cnt);

#ifdef LOG
			clock_gettime(CLOCK_REALTIME, &begin);
#endif

			// Do not use i here.i is the payload index.
			if (new_set_cnt != set_cnt)
			{
				syslog(LOG_INFO,"---------Flushing mqueue..\n");
				for(j = 0; j < MQ_LENGTH; j++)
				{
					mq_timedreceive(mqd, mq_buffer, (size_t)sizeof(void *), NULL, &mq_timeout); 
				}
				
				new_set_cnt = set_cnt;
				syslog(LOG_INFO,"---------mqueue flushed ..\n");
			}


			// sprintf(PPM_fname, "%d.ppm", frm_no);
			payload[i].set_no = set_cnt;

			memset(timestamp, 0, sizeof(timestamp));
			memset(payload[i].im_header, 0 , sizeof(payload[i].im_header)); // IMPORTANT. Else will cause stack smash.strcat cannot find null char.
			uname(&unamedata);
			// memset(str_uname, 0, sizeof(str_uname));
			//M.S.nsec format - Absolute time
			sprintf(timestamp, "#%ld.%d.%ld\n", (timestamp_struct.tv_sec/60), (int)(timestamp_struct.tv_sec%60), (timestamp_struct.tv_nsec));
			sprintf(str_uname, "#%s %s %s %s %s\n", unamedata.sysname, unamedata.nodename,
				unamedata.release, unamedata.version, unamedata.machine);

			

#ifdef GRAY			

			// Constructing PPM header
			strcat(payload[i].im_header, "P5\n");
			strcat(payload[i].im_header, timestamp);
			strcat(payload[i].im_header, str_uname);
			strcat(payload[i].im_header, HRES_STR);
			strcat(payload[i].im_header, " ");
			strcat(payload[i].im_header, VRES_STR);
			strcat(payload[i].im_header, "\n");
			strcat(payload[i].im_header, "255\n");	
#endif


#ifdef RGB			
			//M.S.nsec format - Absolute time
			sprintf(timestamp, "#%ld.%d.%ld\n", (timestamp_struct.tv_sec/60), (int)(timestamp_struct.tv_sec%60), (timestamp_struct.tv_nsec));
			// Constructing PPM header
			strcat(payload[i].im_header, "P6\n");
			strcat(payload[i].im_header, timestamp);
			strcat(payload[i].im_header, str_uname);
			strcat(payload[i].im_header, HRES_STR);
			strcat(payload[i].im_header, " ");
			strcat(payload[i].im_header, VRES_STR);
			strcat(payload[i].im_header, "\n");
			strcat(payload[i].im_header, "255\n");	
#endif

			mq_payload = &payload[i];
			memcpy(mq_buffer, &mq_payload, sizeof(void *));

			if (capture_cnt != -1)
			{
				mq_send(mqd, mq_buffer, (size_t)sizeof(void *), MSG_PRI);
				perror("message send");
			}

			syslog(LOG_INFO,"payload index: %d\n", i);

			

#ifdef LOG
			clock_gettime(CLOCK_REALTIME, &end);
			et_send = d_ftime(&begin, &end);
			if (et_send > wcet_send) wcet_send = et_send;
#endif

			syslog(LOG_INFO,"send  complete : %ld\n", capture_cnt);
			capture_cnt++;

			if ((capture_cnt % (SEQ_FREQ / (CAP_FREQ_MOD * FPS))) == 0) set_cnt++;
			sem_post(&sem);
		}

		// Don't do mq unlink here.Do in main
		syslog(LOG_INFO,"Exiting send service\n");
		pthread_exit(NULL);

	}

	
}

unsigned int find_diffsum(char * prevBuff, char *buff, char *bin, int size)
{
	int i;
	unsigned int diffsum = 0;

	for (i = 0; i < size; i++)
	{

		// diffsum += abs(prevBuff[i] - buff[i]); 
		bin[i] = abs(prevBuff[i] - buff[i]); 

	}

	for (i = 0;i < PIXELS; i++)
	{

		bin[i] = bin[i] > ((BIN_THRESH)*(MAXVAL)) ? 1 : 0;
		if (bin[i] == 1) diffsum++;

	}

	return diffsum;


}

void *select_image(void *threadp)
{
	mask_sig();
	int i=0, msg_prio, c_flag = 0, good_cnt = 0;	

	char mq_buffer[sizeof(void *)];
	
	char bin[PIXELS];
	unsigned int diffsum; 
	// double maxdiff = (PIXELS) * (MAXVAL) ;
	double maxdiff = (PIXELS);
	double percent_diff = 0;
	double new_diff_thresh = 0;

	typedef_payload *curr_payload = NULL;
	typedef_payload *prev_payload = NULL;
	typedef_payload *good_payload = NULL;



	frm_no = 0;
	msg_prio = 30;
   while (1)
   {
		
		if (stop_bit == 1) break;
		//sem_wait(&sem);
		syslog(LOG_INFO,"Image save start %d\n", frm_no);

// #ifdef LOG
// 		clock_gettime(CLOCK_REALTIME, &begin);
// #endif		

		mq_receive(mqd, mq_buffer, (size_t)sizeof(void *), &msg_prio); 
		perror("message receive");
		memcpy(&curr_payload, mq_buffer, sizeof(void *));
		prev_payload =  curr_payload;
	
		new_diff_thresh = (double)DIFF_THRESH;
		good_cnt = 0;
		while (1)
		{			

			mq_receive(mqd, mq_buffer, (size_t)sizeof(void *), &msg_prio); 
			perror("message receive");
			memcpy(&curr_payload, mq_buffer, sizeof(void *));


			diffsum = find_diffsum(prev_payload->g_buffer, curr_payload->g_buffer, bin, PIXELS);
			percent_diff = (diffsum / maxdiff) * 100;
			syslog(LOG_INFO,"--------------------p diff : %0.17f\n", percent_diff);
			syslog(LOG_INFO,"--------------------set no: %d -----  set no match(frm): %d\n", curr_payload->set_no, frm_no);
	


			// if ((good_cnt == 2) || (curr_payload->set_no > frm_no))
			if (curr_payload->set_no > frm_no)
			{

				break;
			}

			if (percent_diff > (double)DIFF_THRESH)
			{
				prev_payload = curr_payload;
				continue;

			}

			else if ((curr_payload->set_no == frm_no) && (percent_diff <= (double)new_diff_thresh))
			{			
				
				new_diff_thresh = percent_diff;
				good_payload = curr_payload;
				prev_payload = curr_payload;
				syslog(LOG_INFO,"---------------good payload foun\n");		
				good_cnt++;
				if (percent_diff == (double)0.0) break;
				if (good_cnt == 1) break;
			}


		}

#ifdef GRAY
		//test
		// Save the image in disk
		char PGM_fname[18];
		// memset(PPM_fname, 0, sizeof(PPM_fname));
		sprintf(PGM_fname, "gray_%d.pgm", frm_no);
		save_image(PGM_fname, good_payload->im_header, good_payload->g_buffer, PIXELS);		
#endif

#ifdef RGB
		//test
		// Save the image in disk
		char PGM_fname[18];

		// memset(PPM_fname, 0, sizeof(PPM_fname));
		sprintf(PGM_fname, "rgb_%d.ppm", frm_no);
		save_image(PGM_fname, good_payload->im_header, good_payload->c_buffer, ((PIXELS)*3));		
#endif


#ifdef DTI
		char PGM_file[18];
		char PGM_header[50];
		memset(PGM_header, 0 , sizeof(PGM_header)); // IMPORTANT. Else will cause stack smash.strcat cannot find null char.
		memset(PGM_file, 0 , sizeof(PGM_file));
		sprintf(PGM_file, "bin_%d.pgm", frm_no);
		strcat(PGM_header, "P5\n");

		strcat(PGM_header, HRES_STR);
		strcat(PGM_header, " ");
		strcat(PGM_header, VRES_STR);
		strcat(PGM_header, "\n");
		strcat(PGM_header, "1\n");	

		save_image(PGM_file, PGM_header, bin, PIXELS);

		
#endif		

#ifdef SOC
		mq_send(mqd1, (char *)&frm_no, sizeof(int), msg_prio); 
#endif

// #ifdef LOG
// 		clock_gettime(CLOCK_REALTIME, &end);
// 		et_bw = d_ftime(&begin, &end);
// 		et_bw += et_process;
// 		if (et_bw > wcet_bw) wcet_bw = et_bw;
// #endif
		syslog(LOG_INFO,"Image save complete %d\n", frm_no);
		frm_no++;
		//sem_post(&sem);
		
		if (frm_no >= FRAME_COUNT) break;
	}
	syslog(LOG_INFO,"Exiting image selector\n");
	pthread_exit(NULL);
	
}


void *soc_image(void *threadp)
{
	mask_sig();
	
	int fts; // frame to send
	char frm_name[30];
	int fd2, read_size, write_size;
	char ack;
	while(1)
	{
		if (stop_bit == 1) break;


		// mq receive here
		mq_receive(mqd1, (char *)&fts, sizeof(int), NULL);  

		syslog(LOG_INFO,"Socket send frame start : %d\n", fts);

#ifdef GRAY
		sprintf(frm_name, "gray_%d.pgm", fts);
		fd2 = open(frm_name, O_RDWR, 0777);
		if (fd2 < 0) {perror("While opening in soc_image"); exit(1);}
#endif

#ifdef RGB
		sprintf(frm_name, "rgb_%d.ppm", fts);
		fd2 = open(frm_name, O_RDWR, 0777);
		if (fd2 < 0) {perror("While opening in soc_image"); exit(1);}
#endif

		read_size = read(fd2, frm_buffer, sizeof(frm_buffer));
		send(socket_desc, &read_size, sizeof(int), 0);
		recv(socket_desc, &ack, sizeof(char), 0);
		write_size = send(socket_desc, frm_buffer, read_size, 0);
		recv(socket_desc, &ack, sizeof(char), 0);
		syslog(LOG_INFO,"read size : %d\n", read_size);
		
		if (write_size == read_size) syslog(LOG_INFO,"frame %d transferred\n", fts);


		syslog(LOG_INFO,"Socket send frame complete : %d", fts);
		close(fd2);
		sched_yield();
	}

	// send(socket_desc, "C", 1, 0);
	close(socket_desc);
	pthread_exit(NULL);

}






// Code source: https://stackoverflow.com/questions/10936733/how-to-write-to-a-second-column-in-excel-in-c
//              https://www.tutorialspoint.com/c_standard_library/c_function_perror.htm
void *logger(void *threadp)
{
	mask_sig();
	FILE * fp2 = NULL;

	double capture_jitter; // frame capture exec time  - deadline per frame
	double send_jitter; // send execution time - deadline per frame
	double seq_jitter; // sequencer execution time - deadline per frame

	fp2 = fopen("wcet.csv", "w");

	if(fp2 == NULL){
		perror("Opening csv file");
		exit(1);
	}
	
	fprintf(fp2, "%s,%d,%d", "RESOLUTION", HRES, VRES);
	fprintf(fp2, "\n");
	fprintf(fp2, "%s,%lf", "Services deadline", deadline); // relative deadline
	fprintf(fp2, "\n");
	fprintf(fp2, "%s,%lf", "Sequencer deadline", s_deadline); // relative deadline
	fprintf(fp2, "\n");
	fprintf(fp2, "ALL UNITS, SECONDS"); // time scale legend
	fprintf(fp2, "\n");
   //  Dont print deadline here.Deadline calculated inside sequencer.Not avaialable at this point.
	fprintf(fp2, "%s,%s,%s,%s,%s,%s\n", "et_capture", "et_send", "et_sequencer", 
		"capture jitter", "send jitter", "Sequencer jitter");

   while (1)
   {
		sem_wait(&semL);
		if (stop_bit == 1) break;
		sem_wait(&sem);


		capture_jitter = et_capture - deadline; // jitter in the capture service relative to deadline
		send_jitter = et_send - deadline; // jitter in the send service relative to deadline
		seq_jitter = et_sequencer - s_deadline; // jitter in the sequencer  relative to deadline

		fprintf(fp2, "%lf,%lf,%lf,%lf,%lf,%lf\n", et_capture, et_send, et_sequencer, 
			capture_jitter, send_jitter, seq_jitter);

		sem_post(&sem);

	}

	fprintf(fp2, "\n");
	fprintf(fp2, "%s,%s,%s\n", "wcet_capture", "wcet_send", "wcet_sequencer");
	fprintf(fp2, "%lf,%lf,%lf\n", wcet_capture, wcet_send, wcet_sequencer);
	

	

	fclose(fp2);

}

sigset_t set;
int sig;

void *sequencer(void *threadp)
{
	mask_sig(); syslog(LOG_INFO,"Sequencer waits on sigwait now\n");

	while(1)
	{		
		sigwait(&set, &sig);

#ifdef LOG
		clock_gettime(CLOCK_REALTIME, &s_begin);
#endif
		

		if (first == 1)
		{
			clock_gettime(CLOCK_REALTIME, &start);
			clock_gettime(CLOCK_REALTIME, &runtime);
			time_elapsed = d_ftime(&start, &runtime);
			syslog(LOG_INFO,"------Sequencer start. Time elapsed: %4.2fs------\n", time_elapsed);
			first = 0;
		}
		else
		{


			clock_gettime(CLOCK_REALTIME, &runtime);
			time_elapsed = d_ftime(&start, &runtime);
			syslog(LOG_INFO,"------Sequencer wake up at %4.4fs------\n", time_elapsed);
			// syslog(LOG_INFO,"------Processed frame number: %d-------\n", frm_no);
			syslog(LOG_INFO,"------Sequence count: %ld-------\n", seq_cnt);
		
		}

		

		if ((seq_cnt % CAP_FREQ_MOD) == 0)
		{
			sem_post(&semC);
		
		}
			

		if (((seq_cnt % CAP_FREQ_MOD) == 0) && (seq_cnt >= SEQ_FREQ))
		{
			sem_post(&semS);
			
		}

	
		// sem_post(&semG);
		// sem_post(&semB);
#ifdef LOG
			sem_post(&semL);
#endif
		// seq_timeout.tv_sec = (timeout_calc /1000000000);
		// seq_timeout.tv_nsec = (timeout_calc % 1000000000);

		// seq_timeout.tv_sec = 0;
		// seq_timeout.tv_nsec = 9825000;
			

		seq_cnt++;

#ifdef LOG
		clock_gettime(CLOCK_REALTIME, &s_end);
		et_sequencer = d_ftime(&s_begin, &s_end);
		if (et_sequencer > wcet_sequencer) wcet_sequencer = et_sequencer;
		syslog(LOG_INFO,"et_sequencer: %lf\n", et_sequencer);
#endif


		if (frm_no >= FRAME_COUNT) 
		{

			
			/* disarm the interval timer */
			itime.it_interval.tv_sec = 0;
			itime.it_interval.tv_nsec = 0;
			itime.it_value.tv_sec = 0;
			itime.it_value.tv_nsec = 0;
			timer_settime(timer_1, 0, &itime, &last_itime);

			syslog(LOG_INFO,"Total frames processed: %d\n", frm_no);
			syslog(LOG_INFO,"Elapsed time : %lfs\n", time_elapsed);
			float avg_fps = (frm_no / time_elapsed);

			syslog(LOG_INFO,"Average frame rate : %4.4f fps\n", avg_fps);
			syslog(LOG_INFO,"Configured frame rate : %d fps\n", FPS);
			syslog(LOG_INFO,"Exiting Sequencer\n");

			stop_bit = 1;
			sem_post(&semC);
			sem_post(&semS);
			// sem_post(&semG);
			// sem_post(&semB);
#ifdef LOG	
			sem_post(&semL);
#endif	
			break;

		}



	}

	pthread_exit(NULL);

}

void handler(int signum)
{
	syslog(LOG_INFO,"handler\n");
}


int main (int argc, char *argv[])
{

	mask_sig();

	// Declarations here
   int rc, policy;
   int i, result = 0;
   cpu_set_t tcpu;
	cpu_set_t nrtcpu;
   typedef_threadParams threadParams[NUM_THREADS];
	pthread_t threads[NUM_THREADS];
	pthread_t ss_thread;
	pthread_t soc_thread;

	pthread_attr_t rt_sched_attr[NUM_THREADS];
	pthread_attr_t nrt_sched_attr[NR_THREADS];
   int rt_max_prio, rt_min_prio, nrt_max_prio;
   struct sched_param rt_sched_param[NUM_THREADS];
	struct sched_param nrt_sched_param[NR_THREADS];
   struct sched_param main_param;

	openlog("Synchronome", LOG_CONS | LOG_NDELAY, LOG_LOCAL7);

#ifdef SOC
	// Create socket here
	socket_desc = socket(AF_INET, SOCK_STREAM, 0);
	if (socket_desc == -1) perror("While creating socket");

	server_addr.sin_family = AF_INET; // IPv4
	server_addr.sin_port = htons(2000); // hton converts to network byte order
	server_addr.sin_addr.s_addr = inet_addr("10.0.0.8"); // inet_addr converts to network byte order


	// Send connection request to server:
	if(connect(socket_desc, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0)
	{
	
		perror("While connecting to server");
		exit(1);
	}

	syslog(LOG_INFO,"Can talk to server now\n");

#endif

	// init message queue here
	attr.mq_maxmsg = MQ_LENGTH;
	attr.mq_msgsize = sizeof(void *); // size of any pointer
	// Created in /dev/mqueue/ folder
	mqd = mq_open(MESSAGE_Q, O_CREAT | O_RDWR, 0777, &attr);
	if (mqd == -1)
	{
		perror("Message queue creation");
		exit(1);
	}

#ifdef SOC
	// init message queue here
	attr1.mq_maxmsg = 10;
	attr1.mq_msgsize = sizeof(int); // size of any pointer
	// Created in /dev/mqueue/ folder
	mqd1 = mq_open(MESSAGE_Q1, O_CREAT | O_RDWR, 0777, &attr1);
	if (mqd == -1)
	{
		perror("Message queue1 creation");
		exit(1);
	}	
 #endif 

	rt_max_prio = sched_get_priority_max(SCHED_FIFO);
	// rc = sched_getparam(getpid(), &main_param);
	main_param.sched_priority = rt_max_prio;

	// Set the scheduling polic of the main thread to SCHED_FIFO
	// priority = 99 i.e. highest priority
	if (sched_setscheduler(getpid(), SCHED_FIFO, &main_param)) { perror("Main thread set scheduler"); exit(1);};
	
	policy = sched_getscheduler(getpid());
	if (policy == SCHED_FIFO) syslog(LOG_INFO,"Main thread policy is SCHED_FIFO\n");

	// Settting the priority for the tasks
	for(i = 0; i < NUM_THREADS; i++)
	{
		
		// Select cpu core 3 
		CPU_ZERO(&tcpu);
		CPU_SET(3, &tcpu);


		if (pthread_attr_init(&rt_sched_attr[i])) { perror("while configuring thread attribute"); exit(1); }
		if (pthread_attr_setinheritsched(&rt_sched_attr[i], PTHREAD_EXPLICIT_SCHED)) { perror("while configuring thread attribute"); exit(1); }
		if (pthread_attr_setschedpolicy(&rt_sched_attr[i], SCHED_FIFO)) { perror("while configuring thread attribute"); exit(1); }
		if (pthread_attr_setaffinity_np(&rt_sched_attr[i], sizeof(cpu_set_t), &tcpu)) { perror("while configuring thread attribute"); exit(1); }
		pthread_attr_getschedpolicy(&rt_sched_attr[i], &policy);

		if (policy == SCHED_FIFO) syslog(LOG_INFO,"Service thread index %d policy is SCHED_FIFO\n", i);

		// Set the priority of the thread here
		rt_sched_param[i].sched_priority = rt_max_prio - i;
		rc = pthread_attr_setschedparam(&rt_sched_attr[i], &rt_sched_param[i]);
		if (rc != 0)
		{
			perror("While Setting thread priority");
			exit(1);
		}

		threadParams[i].threadIdx = i;
		
	}

	nrt_max_prio = sched_get_priority_min(SCHED_OTHER);
	// syslog(LOG_INFO,"nrt max pri: %d\n", nrt_max_prio);

	for(i = 0; i < NR_THREADS; i++)
	{
		
		// Select cpu core 3 
		CPU_ZERO(&nrtcpu);
		CPU_SET(2, &nrtcpu);


		if (pthread_attr_init(&nrt_sched_attr[i])) { perror("while configuring nrt thread attribute"); exit(1); }
		if (pthread_attr_setinheritsched(&nrt_sched_attr[i], PTHREAD_EXPLICIT_SCHED)) { perror("while configuring nrt thread attribute"); exit(1); }
		if (pthread_attr_setschedpolicy(&nrt_sched_attr[i], SCHED_OTHER)) { perror("while configuring nrt thread attribute"); exit(1); }
		if (pthread_attr_setaffinity_np(&nrt_sched_attr[i], sizeof(cpu_set_t), &nrtcpu)) { perror("while configuring nrt thread attribute"); exit(1); }

		pthread_attr_getschedpolicy(&nrt_sched_attr[i], &policy);

		if (policy == SCHED_OTHER) syslog(LOG_INFO,"NRT Service thread index %d policy is SCHED_OTHER\n", i);
		nrt_sched_param[i].sched_priority = 0;
		rc = pthread_attr_setschedparam(&nrt_sched_attr[i], &nrt_sched_param[i]);
		// syslog(LOG_INFO,"nrt pri : %d\n", nrt_sched_param[i].sched_priority);
		if (rc != 0)
		{
			perror("While Setting nr thread priority");
			exit(1);
		}
		
	}

	// init the semaphore here
	// start value 0.Shared amonh threads.
	if (sem_init(&semC, 0, 0)) {perror("While semakey init"); exit(1);}
	if (sem_init(&semS, 0, 0)) {perror("While semakey init"); exit(1);}
	if (sem_init(&sem, 0, 1)) {perror("While semakey init"); exit(1);} // Command for 2 service threads below.Not used in sequencer.
	// if (sem_init(&semG, 0, 0)) {perror("While semakey init"); exit(1);}
	// if (sem_init(&semB, 0, 0)) {perror("While semakey init"); exit(1);}
#ifdef LOG	
	if (sem_init(&semL, 0, 0)) {perror("While semakey init"); exit(1);}
#endif

	// Non RT BE service - select and save
	pthread_create(&ss_thread,   
						&nrt_sched_attr[0],     
						select_image, 
						NULL 
					);

#ifdef SOC
	// Non RT BE service - socket send
	pthread_create(&ss_thread,   
						&nrt_sched_attr[1],     
						soc_image, 
						NULL 
					);
	
#endif
   // spawn image capture and image sharpen service thread here
  
	pthread_create(&threads[1],   
						&rt_sched_attr[1],     
						capture_image, 
						&threadParams[1] 
					);

	pthread_create(&threads[2],   
						&rt_sched_attr[2],     
						capture_image, 
						&threadParams[2] 
					);



#ifdef LOG

	pthread_create(&threads[3],   
				&rt_sched_attr[3],     
				logger, 
				&threadParams[3] 
			);

#endif

	sleep(3); // Let the above 2 threads start and try to take the semakey.
	// launch the sequencer thread here
	pthread_create(&threads[0],   
					&rt_sched_attr[0],     
					sequencer, 
					&threadParams[0] 
				);

	sigaddset(&set, SIGRTMIN);
	sleep(2);

	// Arm seq timer and handler here.
	/* set up to signal SIGALRM if timer expires */
	
	sev.sigev_notify = SIGEV_SIGNAL;
	sev.sigev_signo = SIGRTMIN;// Highest priority real-time signal
	timer_create(CLOCK_REALTIME, &sev, &timer_1);

	
	// signal(SIGRTMIN, (void(*)()) handler);

	long int timeout_calc = (int)((1.0/SEQ_FREQ)*(SEC_TO_MSEC)*(NSEC_PER_MSEC));

	/* arm the interval timer */
	itime.it_interval.tv_sec = (timeout_calc /1000000000);
	itime.it_interval.tv_nsec = (timeout_calc % 1000000000);
	itime.it_value.tv_sec = 0;
	itime.it_value.tv_nsec = 1;
	//itime.it_interval.tv_sec = 1;
	//itime.it_interval.tv_nsec = 0;
	//itime.it_value.tv_sec = 1;
	//itime.it_value.tv_nsec = 0;

	// deadline = (timeout_calc / 1000000000.0); // nanosec to seconds
	// gun shot method
	syslog(LOG_INFO,"Press any key to start\n");
	getchar();

   timer_settime(timer_1, 0, &itime, &last_itime);	

   for(i=0; i < NUM_THREADS; i++)
   {
      pthread_join(threads[i], NULL);   

   }
   
	pthread_join(ss_thread, NULL);


	pthread_attr_destroy(&rt_sched_attr[0]);
	pthread_attr_destroy(&rt_sched_attr[1]);

	// pthread_attr_destroy(&rt_sched_attr[3]);
	// pthread_attr_destroy(&rt_sched_attr[4]);
#ifdef LOG	
	pthread_attr_destroy(&rt_sched_attr[2]);
#endif

	sem_destroy(&semC);
	sem_destroy(&semS);
	sem_destroy(&sem);
	// sem_destroy(&semG);
	// sem_destroy(&semB);
#ifdef LOG	
	sem_destroy(&semL);
#endif	

   syslog(LOG_INFO,"EXITING\n");
   exit(0);
}